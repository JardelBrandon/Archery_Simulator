Arduino---Java---JavaDuino
==========================

Código Arduino y JAVA para establecer una comunicación entre la placa y JAVA por puerto serial.

Para descargarlo:
~~~
git clone https://github.com/GeekyTheory/Arduino---Java---JavaDuino.git
~~~

Para más información, visitar: [Geeky Theory Tutorial](http://www.geekytheory.com/tutorial-java-arduino-javaduino/ "")